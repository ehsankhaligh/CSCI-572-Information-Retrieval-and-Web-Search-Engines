import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Set;
import java.util.regex.Pattern;

import edu.uci.ics.crawler4j.crawler.*;
import edu.uci.ics.crawler4j.parser.*;
import edu.uci.ics.crawler4j.url.WebURL;

public class MyCrawler extends WebCrawler {
	CrawlData crawlData;
	String newsSiteName = "foxnews";
	String newsSiteDomainHttps = "https://www.foxnews.com/";
	String newsSiteDomainHttp = "https://www.foxnews.com/";
	private final static Pattern FILTERS = Pattern.compile(".*(\\.(css|js|gif|jpg|png|mp3|mp4|zip|gz))$");
    
	public MyCrawler(){
		crawlData = new CrawlData();
	}
	
	public static String normalizeUrl(String url){
		
		return url.toLowerCase().replace(",","_");
	}
	
	@Override
	public boolean shouldVisit(Page referringPage, WebURL url){
		String href = normalizeUrl(url.getURL());
				
		if (href.startsWith(newsSiteDomainHttps) || href.startsWith(newsSiteDomainHttp)){
			crawlData.addDiscoveredUrls(url.getURL(), "OK");
		}
		else{
			crawlData.addDiscoveredUrls(url.getURL(), "N_OK");
		}
		
		return !FILTERS.matcher(href).matches() && (href.startsWith(newsSiteDomainHttps) || href.startsWith(newsSiteDomainHttp));
	}
	
	@Override
	public void handlePageStatusCode(WebURL url, int statusCode, String statusDescription){
		crawlData.addFetchedUrls(url.getURL(), statusCode);
	}
	
	@Override
	public void visit(Page page){
		String url = page.getWebURL().getURL();
		//String contentType = page.getContentType().toLowerCase().split(";")[0];
		String contentType = page.getContentType().toLowerCase();
				
		//System.out.println(contentType);
		
        try {
            FileWriter writer = new FileWriter("MyFile.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
 
            bufferedWriter.write(url);
            bufferedWriter.newLine();
            bufferedWriter.write(contentType);
            bufferedWriter.newLine();
            bufferedWriter.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		
		if (contentType.contains("text/html")){ //check
			if (page.getParseData() instanceof HtmlParseData)
			{
				HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
				Set<WebURL> links = htmlParseData.getOutgoingUrls();				
				crawlData.addVisitedUrls(url, page.getContentData().length, links.size(), contentType);	
			}
		}
		else if (contentType.contains("document") || contentType.contains("pdf") || contentType.contains("gif") || contentType.contains("jpeg") || contentType.contains("png")
				|| contentType.contains("image") || contentType.contains("png") || contentType.contains("jfif") || contentType.contains("doc")){ //check
			crawlData.addVisitedUrls(url, page.getContentData().length, 0, contentType);
		}
	}
	
	@Override
	public Object getMyLocalData(){
		return crawlData;
	}
}
