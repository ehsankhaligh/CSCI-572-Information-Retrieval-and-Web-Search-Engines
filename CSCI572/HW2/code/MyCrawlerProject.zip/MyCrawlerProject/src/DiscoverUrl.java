class DiscoverUrl{
	String url;
	String residenceIndicator;
	
	public DiscoverUrl(String url, String residenceIndicator){
		this.url = url;
		this.residenceIndicator = residenceIndicator;
	}
}