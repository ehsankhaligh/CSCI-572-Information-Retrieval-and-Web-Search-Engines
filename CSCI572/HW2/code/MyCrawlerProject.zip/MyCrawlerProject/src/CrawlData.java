import java.util.ArrayList;

public class CrawlData {
	ArrayList<FetchUrl> fetchedUrls;
	ArrayList<VisitUrl> visitedUrls;
	ArrayList<DiscoverUrl> discoveredUrls;
	
	public CrawlData(){
		fetchedUrls = new ArrayList<FetchUrl>();
		visitedUrls = new ArrayList<VisitUrl>();
		discoveredUrls = new ArrayList<DiscoverUrl>();
	}
	
	public void addFetchedUrls(String url, int statusCode){
		this.fetchedUrls.add(new FetchUrl(url, statusCode)); //adds new FetchUrl object to fetchedUrls Arraylist
	}
	
	public void addVisitedUrls(String url, int size, int noOfOutlinks, String contentType){
		this.visitedUrls.add(new VisitUrl(url, size, noOfOutlinks, contentType));
	}
	
	public void addDiscoveredUrls(String url, String residenceIndicator){
		this.discoveredUrls.add(new DiscoverUrl(url, residenceIndicator));
	}
}