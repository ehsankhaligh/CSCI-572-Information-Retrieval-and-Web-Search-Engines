class FetchUrl{
	String url;
	int statusCode;
	
	public FetchUrl(String url, int statusCode){
		this.url = url;
		this.statusCode = statusCode;
	}
}