class VisitUrl{
	String url;
	int size;
	int noOfOutlinks;
	String contentType;
	
	public VisitUrl(String url, int size, int noOfOutlinks, String contentType){
		this.url = url;
		this.size = size;
		this.noOfOutlinks = noOfOutlinks;
		this.contentType = contentType;
	}
}